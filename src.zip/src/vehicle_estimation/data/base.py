from __future__ import annotations

from abc import ABC, abstractmethod

import pandas as pd

from vehicle_estimation.core.types import Event


class DatasetAdapter(ABC):
    @abstractmethod
    def load(self) -> tuple[list[Event], pd.DataFrame]:
        """Return estimator-facing events and a separate ground-truth frame."""
        pass
