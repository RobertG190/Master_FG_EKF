from __future__ import annotations

import numpy as np
import pandas as pd

from vehicle_estimation.core.types import Event, EventKind
from vehicle_estimation.models.linear_single_track import LinearSingleTrack2DOF
from vehicle_estimation.sensors.lateral_acceleration import LateralAccelerationMeasurement
from vehicle_estimation.sensors.yaw_rate import YawRateMeasurement
from .base import DatasetAdapter


class Synthetic2DOFDataset(DatasetAdapter):
    def __init__(
        self,
        model: LinearSingleTrack2DOF,
        yaw_sensor: YawRateMeasurement,
        ay_sensor: LateralAccelerationMeasurement,
        *,
        duration_s: float,
        dt_s: float,
        seed: int,
        vx_base_mps: float,
        vx_variation_mps: float,
        steering_amplitude_rad: float,
        steering_frequency_hz: float,
        truth_process_std: np.ndarray | None = None,
    ):
        self.model = model
        self.yaw_sensor = yaw_sensor
        self.ay_sensor = ay_sensor
        self.duration_s = float(duration_s)
        self.dt_s = float(dt_s)
        self.seed = int(seed)
        self.vx_base = float(vx_base_mps)
        self.vx_var = float(vx_variation_mps)
        self.delta_amp = float(steering_amplitude_rad)
        self.delta_freq = float(steering_frequency_hz)
        self.truth_process_std = (
            np.zeros(2) if truth_process_std is None else np.asarray(truth_process_std, dtype=float)
        )

    def load(self) -> tuple[list[Event], pd.DataFrame]:
        rng = np.random.default_rng(self.seed)
        times = np.arange(0.0, self.duration_s + 0.5 * self.dt_s, self.dt_s)
        x = np.zeros(2)
        events: list[Event] = []
        truth_rows: list[dict] = []

        prev_t = times[0]
        prev_delta = 0.0
        prev_vx = self.vx_base

        for i, t in enumerate(times):
            if i > 0:
                dt = t - prev_t
                x = self.model.discrete_dynamics(x, delta=prev_delta, vx=prev_vx, dt=dt)
                x = x + self.truth_process_std * np.sqrt(dt) * rng.standard_normal(2)

            # Smooth, persistently exciting but still linear-region steering input.
            delta = self.delta_amp * (
                0.72 * np.sin(2 * np.pi * self.delta_freq * t)
                + 0.28 * np.sin(2 * np.pi * 0.37 * self.delta_freq * t + 0.4)
            )
            vx = self.vx_base + self.vx_var * np.sin(2 * np.pi * 0.035 * t)

            # Inputs are events too. If multiple events share a timestamp, inputs
            # are intentionally inserted before sensor measurements.
            events.append(
                Event(t, t, EventKind.INPUT, "input.longitudinal_velocity", np.array([vx]))
            )
            events.append(
                Event(t, t, EventKind.INPUT, "input.steering_angle", np.array([delta]))
            )

            z_r_true = self.yaw_sensor.predict(x, delta=delta, vx=vx)
            z_ay_true = self.ay_sensor.predict(x, delta=delta, vx=vx)
            z_r = z_r_true + self.yaw_sensor.sigma * rng.standard_normal(1)
            z_ay = z_ay_true + self.ay_sensor.sigma * rng.standard_normal(1)

            events.append(
                Event(
                    t,
                    t,
                    EventKind.MEASUREMENT,
                    self.yaw_sensor.source,
                    z_r,
                    self.yaw_sensor.default_covariance(),
                )
            )
            events.append(
                Event(
                    t,
                    t,
                    EventKind.MEASUREMENT,
                    self.ay_sensor.source,
                    z_ay,
                    self.ay_sensor.default_covariance(),
                )
            )

            truth_rows.append(
                {
                    "time": t,
                    "beta_rad": x[0],
                    "yaw_rate_radps": x[1],
                    "steering_angle_rad": delta,
                    "longitudinal_velocity_mps": vx,
                    "yaw_rate_measured_radps": z_r[0],
                    "lateral_acceleration_measured_mps2": z_ay[0],
                }
            )

            prev_t, prev_delta, prev_vx = t, delta, vx

        return events, pd.DataFrame(truth_rows)
