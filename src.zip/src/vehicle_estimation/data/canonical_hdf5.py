from __future__ import annotations

from pathlib import Path

import h5py
import numpy as np
import pandas as pd

from vehicle_estimation.core.types import Event, EventKind
from .base import DatasetAdapter


class CanonicalHDF5Dataset(DatasetAdapter):
    """Read the dataset-independent canonical HDF5 run format.

    Contract
    --------
    /signals/<source>/time_s : 1-D timestamps
    /signals/<source>/value  : scalar signal values
    group attr ``kind``      : ``input`` or ``measurement``

    Ground truth is kept physically separate:
    /truth/<state_name>/time_s
    /truth/<state_name>/value

    A raw dataset must be converted to this contract exactly once by a
    dataset-specific preprocessor. Estimators never know raw column names,
    MATLAB object layouts, ROS topics, CAN IDs, or source-specific units.
    """

    def __init__(
        self,
        path: str,
        *,
        enabled_sources: list[str] | None = None,
        stride: int = 1,
        start_s: float | None = None,
        end_s: float | None = None,
    ):
        self.path = Path(path)
        self.enabled_sources = set(enabled_sources) if enabled_sources else None
        self.stride = int(stride)
        self.start_s = start_s
        self.end_s = end_s
        if self.stride < 1:
            raise ValueError("stride must be >= 1")

    @staticmethod
    def _decode_attr(value):
        if isinstance(value, bytes):
            return value.decode("utf-8")
        return value

    def _window(self, t: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        t = np.asarray(t, dtype=float).reshape(-1)
        y = np.asarray(y, dtype=float)
        if y.ndim == 2 and y.shape[1] == 1:
            y = y[:, 0]
        y = y.reshape(-1)
        if len(t) != len(y):
            raise ValueError("Canonical signal has different time/value lengths")

        mask = np.ones(len(t), dtype=bool)
        if self.start_s is not None:
            mask &= t >= float(self.start_s)
        if self.end_s is not None:
            mask &= t <= float(self.end_s)
        t = t[mask][:: self.stride]
        y = y[mask][:: self.stride]
        return t, y

    def _load_truth(self, h5: h5py.File) -> pd.DataFrame:
        if "truth" not in h5 or not h5["truth"].keys():
            return pd.DataFrame()

        series: dict[str, tuple[np.ndarray, np.ndarray]] = {}
        for state_name, group in h5["truth"].items():
            if "time_s" not in group or "value" not in group:
                continue
            t, y = self._window(group["time_s"][...], group["value"][...])
            if len(t):
                series[state_name] = (t, y)

        if not series:
            return pd.DataFrame()

        # Use the densest truth series as the reference grid and interpolate
        # other truth channels to it. This keeps the public evaluation API wide
        # while the HDF5 storage itself still supports independent timestamps.
        reference_name = max(series, key=lambda k: len(series[k][0]))
        t_ref = series[reference_name][0]
        out = {"time": t_ref}
        for name, (t, y) in series.items():
            out[name] = y if np.array_equal(t, t_ref) else np.interp(t_ref, t, y)
        return pd.DataFrame(out)

    def load(self) -> tuple[list[Event], pd.DataFrame]:
        if not self.path.exists():
            raise FileNotFoundError(
                f"Canonical run not found: {self.path}\n"
                "Run the dataset-specific preprocessor first."
            )

        events: list[Event] = []
        with h5py.File(self.path, "r") as h5:
            schema = self._decode_attr(h5.attrs.get("schema_version", ""))

            if schema not in {"1.0", "1.1-3dof"}:
                raise ValueError(f"Unsupported canonical schema_version={schema!r}")
            if "signals" not in h5:
                raise ValueError("Canonical file has no /signals group")

            available_sources = set(h5["signals"].keys())
            if self.enabled_sources is not None:
                missing = sorted(self.enabled_sources - available_sources)
                if missing:
                    raise ValueError(
                        "Canonical file is missing required sources: "
                        + ", ".join(missing)
                        + ". Re-run the dataset-specific preprocessor if this file "
                        "was created with an older schema export."
                    )

            for source, group in h5["signals"].items():
                if self.enabled_sources is not None and source not in self.enabled_sources:
                    continue
                kind_raw = self._decode_attr(group.attrs.get("kind", ""))
                if kind_raw not in {EventKind.INPUT.value, EventKind.MEASUREMENT.value}:
                    # Aux/reference channels can coexist in the canonical file
                    # without being forwarded to this estimator.
                    continue
                if "time_s" not in group or "value" not in group:
                    raise ValueError(f"Signal {source!r} misses time_s or value")

                t, y = self._window(group["time_s"][...], group["value"][...])
                kind = EventKind(kind_raw)
                metadata = {
                    str(k): self._decode_attr(v) for k, v in group.attrs.items()
                }
                for ti, yi in zip(t, y, strict=True):
                    events.append(
                        Event(
                            measurement_time=float(ti),
                            arrival_time=float(ti),
                            kind=kind,
                            source=source,
                            value=np.array([float(yi)]),
                            covariance=None,
                            metadata=metadata,
                        )
                    )

            truth = self._load_truth(h5)

        # Physical-time order with inputs before measurements at equal time.
        priority = {EventKind.INPUT: 0, EventKind.MEASUREMENT: 1}
        events.sort(key=lambda e: (e.measurement_time, priority[e.kind], e.source))
        return events, truth
